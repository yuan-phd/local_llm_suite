"""
JSON Schemas for Ollama structured output.
Passed to the 'format' parameter to constrain model output.
"""

EMAIL_CLASSIFIER_SCHEMA = {
    "type": "object",
    "properties": {
        "email_phase": {
            "type": "string",
            "enum": [
                "initial_interest",
                "viewing_request",
                "post_viewing",
                "document_submission",
                "questionnaire_reply",
                "offer",
                "unknown",
            ],
        },
        "confidence": {
            "type": "number",
        },
        "property_reference": {
            "type": ["string", "null"],
        },
        "mentioned_rent": {
            "type": ["number", "null"],
        },
        "full_name": {
            "type": ["string", "null"],
        },
    },
    "required": [
        "email_phase",
        "confidence",
        "property_reference",
        "mentioned_rent",
        "full_name",
    ],
}
